/*************************************************************************
 MARV software: BGEN reader extension - implementation
 See bgenReader.h for scope and format references.
*************************************************************************/
#include "bgenReader.h"
#include <cstring>
#include <sstream>
#include <zlib.h>

#ifdef HAVE_ZSTD
#include <zstd.h>
#endif

namespace {

inline bool readLE(std::ifstream &f, uint32_t &v)
{
    unsigned char b[4];
    f.read(reinterpret_cast<char*>(b), 4);
    if (!f) return false;
    v = (uint32_t)b[0] | ((uint32_t)b[1] << 8) | ((uint32_t)b[2] << 16) | ((uint32_t)b[3] << 24);
    return true;
}

inline bool readLE16(std::ifstream &f, uint16_t &v)
{
    unsigned char b[2];
    f.read(reinterpret_cast<char*>(b), 2);
    if (!f) return false;
    v = (uint16_t)b[0] | ((uint16_t)b[1] << 8);
    return true;
}

inline bool readString(std::ifstream &f, uint32_t len, std::string &out)
{
    out.resize(len);
    if (len == 0) return true;
    f.read(&out[0], len);
    return (bool)f;
}

inline bool readString16(std::ifstream &f, uint16_t len, std::string &out)
{
    out.resize(len);
    if (len == 0) return true;
    f.read(&out[0], len);
    return (bool)f;
}

} // namespace

BgenReader::BgenReader()
    : M(0), N(0), compression(0), layout(2), sampleIdentifiersPresent(false), firstVariantOffset(0)
{
}

BgenReader::~BgenReader()
{
    close();
}

void BgenReader::close()
{
    if (file.is_open()) file.close();
}

bool BgenReader::open(const std::string &path)
{
    file.open(path.c_str(), std::ios::binary);
    if (!file.is_open())
    {
        lastError = "Cannot open BGEN file: " + path;
        return false;
    }

    if (!readHeader())
        return false;

    if (sampleIdentifiersPresent)
    {
        if (!readSampleIdentifierBlock())
            return false;
    }

    file.seekg(firstVariantOffset, std::ios::beg);
    if (!file)
    {
        lastError = "BGEN file truncated before first variant block.";
        return false;
    }
    return true;
}

bool BgenReader::readHeader()
{
    uint32_t offset = 0;
    if (!readLE(file, offset)) { lastError = "Failed to read BGEN 'offset' field."; return false; }

    // Everything from here counts towards 'offset' (i.e. first variant
    // block starts at file position 4 + offset).
    firstVariantOffset = 4ULL + offset;

    uint32_t headerLength = 0;
    if (!readLE(file, headerLength)) { lastError = "Failed to read BGEN header length."; return false; }

    if (!readLE(file, M)) { lastError = "Failed to read BGEN variant count."; return false; }
    if (!readLE(file, N)) { lastError = "Failed to read BGEN sample count."; return false; }

    char magic[4];
    file.read(magic, 4);
    if (!file) { lastError = "BGEN file truncated in header magic number."; return false; }
    // magic is either "bgen" or all zero bytes for backwards compatibility - not enforced further.

    // Free data area: headerLength counts from the start of headerLength
    // field itself (i.e. includes the 4+4+4+4=16 bytes already read),
    // so skip (headerLength - 20) bytes of free-form text.
    if (headerLength < 20)
    {
        lastError = "BGEN header length field is smaller than the mandatory header size (20).";
        return false;
    }
    uint32_t freeBytes = headerLength - 20;
    if (freeBytes > 0)
        file.seekg(freeBytes, std::ios::cur);

    uint32_t flags = 0;
    if (!readLE(file, flags)) { lastError = "Failed to read BGEN flags field."; return false; }

    compression = flags & 0x3u;                 // bits 0-1
    layout      = (flags >> 2) & 0xFu;           // bits 2-5
    sampleIdentifiersPresent = ((flags >> 31) & 0x1u) != 0;

    if (layout != 1 && layout != 2)
    {
        std::stringstream ss;
        ss << "Unsupported BGEN layout (" << layout << "). Only Layout 1 (v1.1) and Layout 2 (v1.2/1.3) are supported.";
        lastError = ss.str();
        return false;
    }
    if (compression == 2)
    {
#ifndef HAVE_ZSTD
        lastError = "This BGEN file uses zstd compression, but MARV was built without zstd support. "
                    "Recompile with 'make WITH_ZSTD=1' (requires libzstd-dev) to read this file.";
        return false;
#endif
    }
    if (compression > 2)
    {
        lastError = "Unrecognised BGEN compression code (only none/zlib/zstd are supported).";
        return false;
    }

    return true;
}

bool BgenReader::readSampleIdentifierBlock()
{
    uint32_t blockLength = 0;
    uint32_t nSamples = 0;
    if (!readLE(file, blockLength)) { lastError = "Failed to read BGEN sample identifier block length."; return false; }
    if (!readLE(file, nSamples))    { lastError = "Failed to read BGEN sample identifier sample count."; return false; }

    if (nSamples != N)
    {
        std::stringstream ss;
        ss << "BGEN sample identifier block declares " << nSamples
           << " samples but the file header declares " << N << ".";
        lastError = ss.str();
        return false;
    }

    for (uint32_t i = 0; i < nSamples; i++)
    {
        uint16_t len = 0;
        if (!readLE16(file, len)) { lastError = "BGEN file truncated while reading sample identifiers."; return false; }
        std::string id;
        if (!readString16(file, len, id)) { lastError = "BGEN file truncated while reading sample identifiers."; return false; }
    }
    return true;
}

bool BgenReader::zlibInflate(const std::vector<unsigned char> &src, std::vector<unsigned char> &dst, unsigned long destLen)
{
    dst.resize(destLen);
    if (destLen == 0) return true;
    unsigned long outLen = destLen;
    int rc = uncompress(dst.data(), &outLen, src.data(), (unsigned long)src.size());
    if (rc != Z_OK || outLen != destLen)
    {
        lastError = "zlib decompression of BGEN genotype block failed.";
        return false;
    }
    return true;
}

bool BgenReader::zstdInflate(const std::vector<unsigned char> &src, std::vector<unsigned char> &dst, unsigned long destLen)
{
#ifdef HAVE_ZSTD
    dst.resize(destLen);
    if (destLen == 0) return true;
    size_t rc = ZSTD_decompress(dst.data(), destLen, src.data(), src.size());
    if (ZSTD_isError(rc) || rc != destLen)
    {
        lastError = "zstd decompression of BGEN genotype block failed.";
        return false;
    }
    return true;
#else
    (void)src; (void)dst; (void)destLen;
    lastError = "zstd support not compiled in.";
    return false;
#endif
}

bool BgenReader::nextVariant(BgenVariant &out)
{
    if (layout == 1)
        return readVariantLayout1(out);
    return readVariantLayout2(out);
}

// ---- Layout 1 (BGEN v1.1) ----------------------------------------------
bool BgenReader::readVariantLayout1(BgenVariant &out)
{
    uint32_t nc = 0;
    if (!readLE(file, nc))
    {
        // Clean EOF if nothing at all could be read.
        lastError.clear();
        return false;
    }

    uint16_t lid = 0, lrsid = 0, lchr = 0;
    if (!readLE16(file, lid))   { lastError = "BGEN (layout1) truncated reading variant id length."; return false; }
    if (!readString16(file, lid, out.variantId)) { lastError = "BGEN (layout1) truncated reading variant id."; return false; }

    if (!readLE16(file, lrsid)) { lastError = "BGEN (layout1) truncated reading rsid length."; return false; }
    if (!readString16(file, lrsid, out.rsid))    { lastError = "BGEN (layout1) truncated reading rsid."; return false; }

    if (!readLE16(file, lchr))  { lastError = "BGEN (layout1) truncated reading chromosome length."; return false; }
    if (!readString16(file, lchr, out.chromosome)) { lastError = "BGEN (layout1) truncated reading chromosome."; return false; }

    uint32_t pos = 0;
    if (!readLE(file, pos)) { lastError = "BGEN (layout1) truncated reading position."; return false; }
    out.position = (int)pos;

    uint32_t la1 = 0, la2 = 0;
    if (!readLE(file, la1)) { lastError = "BGEN (layout1) truncated reading allele1 length."; return false; }
    if (!readString(file, la1, out.allele1)) { lastError = "BGEN (layout1) truncated reading allele1."; return false; }
    if (!readLE(file, la2)) { lastError = "BGEN (layout1) truncated reading allele2 length."; return false; }
    if (!readString(file, la2, out.allele2)) { lastError = "BGEN (layout1) truncated reading allele2."; return false; }

    const unsigned long decompLen = 6UL * N; // 3 x uint16 per sample

    std::vector<unsigned char> probBuf;
    if (compression == 0)
    {
        probBuf.resize(decompLen);
        file.read(reinterpret_cast<char*>(probBuf.data()), decompLen);
        if (!file) { lastError = "BGEN (layout1) truncated reading uncompressed genotype block."; return false; }
    }
    else
    {
        uint32_t compLen = 0;
        if (!readLE(file, compLen)) { lastError = "BGEN (layout1) truncated reading compressed block length."; return false; }
        std::vector<unsigned char> compBuf(compLen);
        file.read(reinterpret_cast<char*>(compBuf.data()), compLen);
        if (!file) { lastError = "BGEN (layout1) truncated reading compressed genotype block."; return false; }

        bool ok = (compression == 1) ? zlibInflate(compBuf, probBuf, decompLen)
                                      : zstdInflate(compBuf, probBuf, decompLen);
        if (!ok) return false;
    }

    out.probs.resize(3UL * N);
    const unsigned char *p = probBuf.data();
    for (uint32_t i = 0; i < N; i++)
    {
        uint16_t v0 = (uint16_t)p[0] | ((uint16_t)p[1] << 8);
        uint16_t v1 = (uint16_t)p[2] | ((uint16_t)p[3] << 8);
        uint16_t v2 = (uint16_t)p[4] | ((uint16_t)p[5] << 8);
        out.probs[3*i+0] = v0 / 32768.0;
        out.probs[3*i+1] = v1 / 32768.0;
        out.probs[3*i+2] = v2 / 32768.0;
        p += 6;
    }

    return true;
}

// ---- Layout 2 (BGEN v1.2 / v1.3) ---------------------------------------
bool BgenReader::readVariantLayout2(BgenVariant &out)
{
    uint16_t lid = 0;
    if (!readLE16(file, lid))
    {
        // Clean EOF.
        lastError.clear();
        return false;
    }
    if (!readString16(file, lid, out.variantId)) { lastError = "BGEN (layout2) truncated reading variant id."; return false; }

    uint16_t lrsid = 0;
    if (!readLE16(file, lrsid)) { lastError = "BGEN (layout2) truncated reading rsid length."; return false; }
    if (!readString16(file, lrsid, out.rsid))    { lastError = "BGEN (layout2) truncated reading rsid."; return false; }

    uint16_t lchr = 0;
    if (!readLE16(file, lchr))  { lastError = "BGEN (layout2) truncated reading chromosome length."; return false; }
    if (!readString16(file, lchr, out.chromosome)) { lastError = "BGEN (layout2) truncated reading chromosome."; return false; }

    uint32_t pos = 0;
    if (!readLE(file, pos)) { lastError = "BGEN (layout2) truncated reading position."; return false; }
    out.position = (int)pos;

    uint16_t K = 0;
    if (!readLE16(file, K)) { lastError = "BGEN (layout2) truncated reading allele count."; return false; }

    std::vector<std::string> alleles(K);
    for (uint16_t k = 0; k < K; k++)
    {
        uint32_t la = 0;
        if (!readLE(file, la)) { lastError = "BGEN (layout2) truncated reading allele length."; return false; }
        if (!readString(file, la, alleles[k])) { lastError = "BGEN (layout2) truncated reading allele."; return false; }
    }

    // Read the (possibly compressed) genotype probability block, regardless
    // of whether we can interpret it, so the stream stays in sync for the
    // next variant.
    std::vector<unsigned char> probData;
    if (compression == 0)
    {
        uint32_t D = 0;
        if (!readLE(file, D)) { lastError = "BGEN (layout2) truncated reading probability data length."; return false; }
        probData.resize(D);
        if (D > 0)
        {
            file.read(reinterpret_cast<char*>(probData.data()), D);
            if (!file) { lastError = "BGEN (layout2) truncated reading uncompressed probability data."; return false; }
        }
    }
    else
    {
        uint32_t C = 0;
        if (!readLE(file, C)) { lastError = "BGEN (layout2) truncated reading compressed block length."; return false; }
        uint32_t D = 0;
        if (!readLE(file, D)) { lastError = "BGEN (layout2) truncated reading decompressed length."; return false; }
        uint32_t compPayloadLen = C - 4; // C counts D (4 bytes) + compressed payload
        std::vector<unsigned char> compBuf(compPayloadLen);
        if (compPayloadLen > 0)
        {
            file.read(reinterpret_cast<char*>(compBuf.data()), compPayloadLen);
            if (!file) { lastError = "BGEN (layout2) truncated reading compressed probability data."; return false; }
        }
        bool ok = (compression == 1) ? zlibInflate(compBuf, probData, D)
                                      : zstdInflate(compBuf, probData, D);
        if (!ok) return false;
    }

    if (K != 2)
    {
        // Multi-allelic variant: MARV's downstream model is strictly
        // bi-allelic. Skip by returning an "empty" variant that the
        // caller recognises via chromosome=="" and retries the loop.
        out.chromosome.clear();
        out.allele1.clear();
        out.allele2.clear();
        out.probs.clear();
        return true;
    }
    out.allele1 = alleles[0];
    out.allele2 = alleles[1];

    if (probData.size() < 10)
    {
        lastError = "BGEN (layout2) probability data block is implausibly short.";
        return false;
    }

    const unsigned char *pd = probData.data();
    uint32_t nProb = (uint32_t)pd[0] | ((uint32_t)pd[1] << 8) | ((uint32_t)pd[2] << 16) | ((uint32_t)pd[3] << 24);
    if (nProb != N)
    {
        lastError = "BGEN (layout2) probability block sample count does not match header sample count.";
        return false;
    }
    uint16_t kProb = (uint16_t)pd[4] | ((uint16_t)pd[5] << 8);
    if (kProb != 2)
    {
        lastError = "BGEN (layout2) probability block declares an allele count inconsistent with the variant record.";
        return false;
    }
    // pd[6] = min ploidy, pd[7] = max ploidy (not otherwise needed: we
    // read per-sample ploidy directly below).
    const unsigned char *ploidyBytes = pd + 8;
    unsigned char phased = pd[8 + N];
    unsigned char B      = pd[8 + N + 1];
    const unsigned char *bitStream = pd + 8 + N + 2;
    size_t bitStreamBytes = probData.size() - (8 + N + 2);

    out.probs.assign(3UL * N, 0.0);

    // Total number of stored probability values across all samples
    // (needed to size the fast path / bounds-check the generic path).
    // For K=2, both phased and unphased encodings store exactly
    // 'ploidy' values per sample (see bgenReader.h for the derivation).
    const double maxVal = (double)((1ULL << B) - 1ULL);

    // For unphased diploid data, the two stored values v0,v1 ARE
    // P(AA), P(AB) directly (P(BB) = 1 - v0 - v1) - this follows the
    // colex-order convention in the spec and has been verified against
    // real BGEN files (Michigan/TOPMed/UKB-style unphased dosage data).
    //
    // For PHASED diploid data, the spec stores, per haplotype, the
    // probability of the *first* allele (not the second): v0 = P(hap1
    // carries allele1), v1 = P(hap2 carries allele1). These must be
    // combined multiplicatively (treating the two haplotype calls as
    // independent) to obtain the unphased genotype triplet MARV expects:
    //   P(AA) = v0*v1; P(AB) = v0*(1-v1) + (1-v0)*v1; P(BB) = (1-v0)*(1-v1)
    auto storeDiploid = [&](uint32_t i, double v0, double v1, bool missing)
    {
        if (missing) { out.probs[3*i+0]=0; out.probs[3*i+1]=0; out.probs[3*i+2]=0; return; }
        if (phased)
        {
            out.probs[3*i+0] = v0 * v1;
            out.probs[3*i+1] = v0 * (1.0 - v1) + (1.0 - v0) * v1;
            out.probs[3*i+2] = (1.0 - v0) * (1.0 - v1);
        }
        else
        {
            double v2 = 1.0 - v0 - v1;
            if (v2 < 0) v2 = 0; // guard against rounding
            out.probs[3*i+0] = v0;
            out.probs[3*i+1] = v1;
            out.probs[3*i+2] = v2;
        }
    };
    // For ploidy 1 (hemizygous, e.g. male chrX), phased/unphased are
    // equivalent (the spec explicitly notes this): a single stored
    // value v0 = P(carries allele1).
    auto storeHemizygous = [&](uint32_t i, double v0, bool missing)
    {
        if (missing) { out.probs[3*i+0]=0; out.probs[3*i+1]=0; out.probs[3*i+2]=0; return; }
        out.probs[3*i+0] = v0;
        out.probs[3*i+1] = 0.0;
        out.probs[3*i+2] = 1.0 - v0;
    };

    if (B == 8)
    {
        // Fast path: byte-aligned, by far the most common case
        // (UK Biobank, Michigan/TOPMed Imputation Server output).
        size_t bytePos = 0;
        for (uint32_t i = 0; i < N; i++)
        {
            unsigned char pbyte = ploidyBytes[i];
            bool missing = (pbyte & 0x80) != 0;
            unsigned int ploidy = pbyte & 0x7F;

            if (ploidy == 2)
            {
                if (bytePos + 2 > bitStreamBytes) { lastError = "BGEN (layout2) probability stream ran out of data (B=8, ploidy=2)."; return false; }
                double v0 = bitStream[bytePos]   / maxVal;
                double v1 = bitStream[bytePos+1] / maxVal;
                bytePos += 2;
                storeDiploid(i, v0, v1, missing);
            }
            else if (ploidy == 1)
            {
                if (bytePos + 1 > bitStreamBytes) { lastError = "BGEN (layout2) probability stream ran out of data (B=8, ploidy=1)."; return false; }
                double v0 = bitStream[bytePos] / maxVal;
                bytePos += 1;
                storeHemizygous(i, v0, missing);
            }
            else
            {
                lastError = "BGEN (layout2) variant has an unsupported sample ploidy (only 1 and 2 are handled).";
                return false;
            }
        }
    }
    else
    {
        // Generic (slower) bit-unpacking path for B != 8.
        size_t bitPos = 0;
        auto readBits = [&](int nbits) -> double {
            uint64_t value = 0;
            for (int b = 0; b < nbits; b++)
            {
                size_t bytePos = bitPos / 8;
                int bitInByte = (int)(bitPos % 8);
                unsigned char bit = (bitStream[bytePos] >> bitInByte) & 1;
                value |= ((uint64_t)bit << b);
                bitPos++;
            }
            return (double)value / maxVal;
        };

        for (uint32_t i = 0; i < N; i++)
        {
            unsigned char pbyte = ploidyBytes[i];
            bool missing = (pbyte & 0x80) != 0;
            unsigned int ploidy = pbyte & 0x7F;

            if (ploidy == 2)
            {
                double v0 = readBits(B);
                double v1 = readBits(B);
                storeDiploid(i, v0, v1, missing);
            }
            else if (ploidy == 1)
            {
                double v0 = readBits(B);
                storeHemizygous(i, v0, missing);
            }
            else
            {
                lastError = "BGEN (layout2) variant has an unsupported sample ploidy (only 1 and 2 are handled).";
                return false;
            }
        }
    }

    return true;
}
