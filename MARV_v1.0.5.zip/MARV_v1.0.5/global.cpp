/*************************************************************************
 MARV software

 Contributors:
 * Marika Kaakinen
 * Reedik M�gi
 * Krista Fischer
 * Andrew P Morris
 * Inga Prokopenko

Copyright (c) 2017, Imperial College London
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*************************************************************************/


#include "global.h"

global::global(void)
{
    version = "1.0.5";
    markerExtraction=false;
    markerExclusion=false;

    missingCode = "NA";
    outputRoot = "marvel";
    removeMissing = false;
    printAll = false;
    printComplex = false;
    printBetas = false;
    printCovariance = false;

    chromosome=0;

}


global::~global(void)
{
}

void
global::createOutput()
{
    outputResult = outputRoot + ".result";
    outputLog = outputRoot + ".log";
    outputBetas = outputRoot + ".betas";
    outputError = outputRoot + ".err";


}



