/*************************************************************************
MARV software:  Jan, 2017

 Contributors:
 * Marika Kaakinen
 * Reedik M�gi
 * Krista Fischer
 * Andrew P Morris
 * Inga Prokopenko

Copyright (c) 2017, Imperial College London
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*************************************************************************/


#pragma once

#include "structures.h"

class lr
{

private:
	matrixD * V;			// Least squares and var/covar matrix
	double RYSQ;			// Multiple correlation coefficient
	double SDV;				// Standard deviation of errors
	double FReg;			// Fisher F statistic for regression
    double VarG;            // Variance of Y for linear regression null likelihood
    double YBAR;            // Defining YBAR
	arrayD * Ycalc;			// Calculated values of Y
	arrayD * DY;			// Residual values of Y

	bool isC, isSEC, isV, isYcalc, isDY, isLogistic;


public:
	arrayD * Cstat;				// Coefficients
	arrayD * SECstat;			// Std Error of coefficients
    matrixD * covariance;			//covar matrix  //not yet implemented in linear regression
	bool lr_w(arrayD * Y, matrixD * X, arrayD * W);	//linear regression
	bool lg_w(arrayD * Y, matrixD * X, arrayD * W);  //logistic regression
    double getLnLk(arrayD * Y, matrixD * X, arrayD * W); // Return -2 * sample log-likelihood
    const double nullLikelihood (const vector<double>& COPYpheno);
    double getFReg(){return FReg;}
	~lr();
};

