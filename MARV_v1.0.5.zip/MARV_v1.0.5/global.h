/*************************************************************************
 MARV software:  Jan, 2017

 Contributors:
 * Marika Kaakinen
 * Reedik M�gi
 * Krista Fischer
 * Andrew P Morris
 * Inga Prokopenko

Copyright (c) 2017, Imperial College London
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*************************************************************************/


#ifndef __GLOBAL_H__
#define __GLOBAL_H__

#include <string>
#include <vector>
#include <map>
#include <stdlib.h> //from pleiotropy

#include "sample.h" //from pleiotropy; needed for defining the vector samples

class global
{
public:
	global(void);
	~global(void);
	void createOutput(void);

	std::string version;
    bool debugMode;
//    unsigned int lowMemory;
	int errNr;
	//bool quantitativeTrait;		//we have quantitative trait (using linear regression instead of logistic one)
	//bool cov_all;				//using all covariates from phenotype file
	bool dosages;				//dosage genotypes for imputed data - false by default
	//int covCount;					//get covariate count
    //std::vector<std::string> covList;                  //list of covariate column names
    //std::vector<double> conditionalData;
	int chromosome;             //chromosome number (X-23, Y-24, XY-25, MT-26)
    //std::string pheno;
    std::vector<std::string> phenoList; //from pleiotropy
    int pheno_ok;
//    int pheno_men_ok;
//    int pheno_women_ok;
	double rareVariantThreshold;
    double callrateThreshold;
    double infoThreshold;
    double flanking;
    int method;
//  int sexColumn;
	std::string inputGenFile;
	std::string inputSampleFile;
	std::string inputMapFile;
	std::string inputExclusionMarkersFile;
    std::string inputExclusionSamplesFile;
	std::string inputExtractMarkersFile;
    std::string inputExtractSamplesFile;
	std::string outputRoot;
	std::string outputResult;
	std::string outputBetas; //from pleiotropy
	std::string outputLog;
	std::string outputError;
//    std::string outputResultM;
//    std::string outputResultF;
	std::string missingCode;
//    std::string sexCode;
//    std::vector <std::string> printGene;
    //std::vector <std::string> covGene;
    //std::vector <std::string> covMarker;
    //std::vector <std::string> covMarkerPos;
    std::map <std::string, bool> extractmarkers;
    std::map <std::string, bool> excludemarkers;
    bool markerExtraction; //from pleiotropy
    bool markerExclusion;
    bool removeMissing;
    bool printAll;
    bool printComplex;
    bool printBetas;
    bool printCovariance;
    std::vector <sample> samples; //this is used in readSampleFile(). Data will be pushed to this matrix

};
#endif
