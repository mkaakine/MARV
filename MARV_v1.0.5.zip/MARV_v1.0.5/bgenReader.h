/*************************************************************************
 MARV software: BGEN reader extension

 Adds support for reading BGEN genotype files (v1.1 "Layout 1" and
 v1.2/v1.3 "Layout 2") as an alternative to the original .gen / .gen.gz
 input.

 Scope / limitations (documented deliberately, since MARV's downstream
 analysis code only ever consumes bi-allelic, diploid genotype data):
   - Only bi-allelic variants are supported (K == 2). Multi-allelic
     BGEN records are skipped with a warning.
   - Sample ploidy is expected to be 2 (autosomal). Hemizygous calls
     (ploidy 1, e.g. male chrX) are decoded but folded into the
     AA/BB slots with the heterozygote probability set to 0 - this is
     a reasonable approximation for rare-variant burden testing but is
     called out here for transparency.
   - Compression: none, zlib (compression=1) always supported since
     MARV already links zlib. zstd (compression=2, the default for
     newer bgenix/qctool output) requires building with -DHAVE_ZSTD
     and -lzstd (see Makefile). Without it, zstd-compressed BGEN files
     fail with a clear runtime error rather than silently misreading.
   - The BGEN sample-identifier block (if present) is read only to
     confirm the sample count; MARV continues to source sample IDs and
     phenotypes exclusively from the --sample file, exactly as before.

 Reference: BGEN v1.2/1.3 format specification,
 https://www.well.ox.ac.uk/~gav/bgen_format/
*************************************************************************/
#ifndef __BGENREADER_H__
#define __BGENREADER_H__

#include <string>
#include <vector>
#include <fstream>
#include <cstdint>

// One decoded variant. Probabilities are expressed in the same
// convention MARV already uses for .gen files: for each sample, three
// consecutive doubles giving P(allele1/allele1), P(allele1/allele2),
// P(allele2/allele2) ("aa", "aA", "AA" in main.cpp's naming).
struct BgenVariant
{
    std::string chromosome;   // raw string as stored in file, e.g. "01", "X", "23", or "" 
    int         position;
    std::string rsid;
    std::string variantId;
    std::string allele1;      // treated as the GEN "effect allele" column
    std::string allele2;      // treated as the GEN "non-effect allele" column
    std::vector<double> probs; // size 3*N, per-sample triplets (aa, aA, AA)
};

class BgenReader
{
public:
    BgenReader();
    ~BgenReader();

    // Opens the file, parses the header and (if present) the sample
    // identifier block. Returns false on failure (see lastError).
    bool open(const std::string &path);
    void close();

    unsigned int numSamples()  const { return N; }
    unsigned int numVariants() const { return M; }

    // Decodes the next variant into 'out'. Returns false at end of
    // file or on unrecoverable error (lastError will be non-empty on
    // error, empty on ordinary end-of-file).
    bool nextVariant(BgenVariant &out);

    std::string lastError;

private:
    std::ifstream file;
    uint32_t M;                     // number of variants
    uint32_t N;                     // number of samples
    uint32_t compression;           // 0 none, 1 zlib, 2 zstd
    uint32_t layout;                // 1 or 2
    bool     sampleIdentifiersPresent;
    uint64_t firstVariantOffset;    // absolute file offset of first variant block

    bool readHeader();
    bool readSampleIdentifierBlock();

    bool readVariantLayout1(BgenVariant &out);
    bool readVariantLayout2(BgenVariant &out);

    bool zlibInflate(const std::vector<unsigned char> &src, std::vector<unsigned char> &dst, unsigned long destLen);
    bool zstdInflate(const std::vector<unsigned char> &src, std::vector<unsigned char> &dst, unsigned long destLen);
};

#endif
