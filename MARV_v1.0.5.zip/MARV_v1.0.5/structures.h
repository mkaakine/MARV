/*************************************************************************
MARV software:  Jan, 2017

 Contributors:
 * Marika Kaakinen
 * Reedik M�gi
 * Krista Fischer
 * Andrew P Morris
 * Inga Prokopenko

Copyright (c) 2017, Imperial College London
All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
may be used to endorse or promote products derived from this software without
specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*************************************************************************/


#pragma once

#include <vector>
using namespace std;

class matrixD
{
private:
	vector <double> _M;
	int _rows;
	int _cols;

public:
	matrixD(int cRow, int cColumn);
	~matrixD(void);
	void put(int row, int column, double value);
	double get(int row, int column);
	int size(){return _rows*_cols;}
	int getRows(){return _rows;}
	int getCols(){return _cols;}
	bool InvertS(); //invert symmetric matrix
	bool print();
};

class arrayD
{
private:
	vector <double> _M;
	int _rows;

public:
	arrayD(int cRow);
	~arrayD(void);
	void put(int row,  double value);
	double get(int row);
	int size(){return _rows;}
    bool print();
};

